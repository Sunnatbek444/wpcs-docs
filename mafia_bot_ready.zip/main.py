
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from threading import Thread
from flask import Flask
import random
import asyncio
import time
import json
import os

app = Flask('')

@app.route('/')
def home():
    return "Mafia bot is running!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

# User credentials
API_ID = 22127885
API_HASH = "88b595f99378172a61a87868ece95972"
BOT_TOKEN = "8012506497:AAHLJyXlDdGGV7wC8yBQJ3rt3YjDhnCuVHA"

bot = Client("mafia_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

players = []
roles = {}
live_players = []
chat_id_global = None
join_phase = False
game_running = False
actions = {
    'mafia': None,
    'don': None,
    'doctor': None,
    'police': None,
    'maniac': None,
    'shooter': None,
    'lovers': [],
    'votes': {}
}

ALL_ROLES = ["Mafia", "Don", "Doctor", "Police", "Maniac", "Shooter", "Lover", "Lover"]
USER_DATA_FILE = "user_data.json"

def load_user_data():
    if os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, "r") as f:
            return json.load(f)
    return {}

def save_user_data(data):
    with open(USER_DATA_FILE, "w") as f:
        json.dump(data, f)

def add_coins(user_id, amount):
    data = load_user_data()
    uid = str(user_id)
    if uid not in data:
        data[uid] = {"coins": 0, "inventory": []}
    data[uid]["coins"] += amount
    save_user_data(data)

def get_balance(user_id):
    data = load_user_data()
    return data.get(str(user_id), {"coins": 0})["coins"]

def spend_coins(user_id, amount):
    data = load_user_data()
    uid = str(user_id)
    if data.get(uid, {}).get("coins", 0) >= amount:
        data[uid]["coins"] -= amount
        save_user_data(data)
        return True
    return False

SHOP_ITEMS = {
    "shield": {"name": "🔰 Himoya qalqoni", "price": 15},
    "change_role": {"name": "🔄 Rol o‘zgartirish", "price": 30},
    "double_vote": {"name": "🗳️ 2x ovoz kuchi", "price": 20}
}

@bot.on_message(filters.command("balance"))
def show_balance(client, message):
    coins = get_balance(message.from_user.id)
    message.reply_text(f"💰 Sizda {coins} tanga bor.")

@bot.on_message(filters.command("shop"))
def show_shop(client, message):
    buttons = [
        [InlineKeyboardButton(f"{item['name']} – {item['price']} coin", callback_data=f"buy_{key}")]
        for key, item in SHOP_ITEMS.items()
    ]
    message.reply_text("🛒 Do‘kon menyusi:", reply_markup=InlineKeyboardMarkup(buttons))

@bot.on_callback_query()
def handle_callbacks(client, callback_query: CallbackQuery):
    data = callback_query.data
    user_id = callback_query.from_user.id

    if data.startswith("buy_"):
        item_key = data.split("_")[1]
        item = SHOP_ITEMS.get(item_key)
        if item:
            if spend_coins(user_id, item["price"]):
                callback_query.answer(f"✅ {item['name']} sotib olindi!", show_alert=True)
            else:
                callback_query.answer("❌ Coin yetarli emas!", show_alert=True)
        else:
            callback_query.answer("❌ Noto‘g‘ri mahsulot.", show_alert=True)
    elif data.startswith("vote_"):
        vote_for = int(data.split("_")[1])
        actions['votes'][user_id] = vote_for
        callback_query.answer("✅ Ovoz berildi")
        callback_query.message.edit_text("🗳 Ovoz berildi.")

keep_alive()
bot.run()
